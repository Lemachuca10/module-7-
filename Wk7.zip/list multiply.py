#Luis Machuca
#2/28/2020
#In this program it will multiply the list [5,2,7,-1]
import time
print ("This is the list that is going to be multiply [5,2,7,-1]? ")
#b represents the result and a represents a variable
# b = 1 to multiply all the numbers in the list 
def multiply(l):
    b = 1
    for a in l:
        b = b * a
    return b
list = [5,2,7,-1]
print ("The answer is? ")
time.sleep(2)
print(multiply(list))
time.sleep(3)

