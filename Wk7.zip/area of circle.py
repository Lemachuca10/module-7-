#Luis Machuca
#2/28/2020

#In this program it calcultate the area of a circle.

import math
radius =float(input("What is the radius? "))
area = math.pi*radius*radius 

print(area)
