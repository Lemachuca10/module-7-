#Luis Machhuca
#2/28/2020
#This program will add two more numbers in the list to create a new list
#Once you run the program it will show the orinal and the new list 
number = [1, 3, 3, 3, 6, 2, 3, 5]
print ("original list: ", number)
number.append(9)
number.append(4)
print("newlist: ",number)
        
